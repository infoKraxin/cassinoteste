const lineImgMap = {
  default: "/activity/rescue_line_default.webp",
  black: "/activity/rescue_line.webp",
  blue: "/activity/rescue_line_default.webp",
  whiteGreen: "/activity/rescue_line_whiteGreen.webp",
  oilyGreen: "/activity/rescue_line_oilyGreen.webp",
  whiteRed: "/activity/rescue_line_oilyGreen.webp",
  versaceYellow: "/activity/rescue_line_versaceYellow.webp",
  lancomePeach: "/activity/rescue_line_oilyGreen.webp",
  hermesOrange: "/activity/rescue_line_hermesOrange.webp",
  whiteBlue: "/activity/rescue_line_whiteBlue.webp",
  whiteDarkGreen: "/activity/rescue_line_whiteDarkGreen.webp",
  sk2: "/activity/rescue_line_sk2.webp"
};
export {
  lineImgMap as l
};

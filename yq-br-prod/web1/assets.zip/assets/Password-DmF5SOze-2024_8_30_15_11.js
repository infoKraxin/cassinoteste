import { K as jsxRuntimeExports, P as joinClass } from "./index-a_Ow1xUN-2024_8_30_15_11.js";
import { ap as css } from "./App-D9NLPZJN-2024_8_30_15_11.js";
const Password = ({ className, isSelect = false } = {}) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: joinClass(css.defaultCss, className), width: "32", height: "32", viewBox: "0 0 32 32", fill: "none", xmlns: "http://www.w3.org/2000/svg", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { fillRule: "evenodd", clipRule: "evenodd", d: "M16 1.33325C11.5817 1.33325 8 4.91498 8 9.33326V16.1679C5.6997 16.76 4 18.8481 4 21.3333V25.3333C4 28.2788 6.38782 30.6666 9.33333 30.6666H22.6667C25.6122 30.6666 28 28.2788 28 25.3332V21.3333C28 18.8481 26.3003 16.76 24 16.1679V9.33325C24 4.91497 20.4183 1.33325 16 1.33325ZM21.3333 15.9999V9.33325C21.3333 6.38773 18.9455 3.99992 16 3.99992C13.0545 3.99992 10.6667 6.38774 10.6667 9.33326V15.9999H21.3333ZM6.66667 21.3333C6.66667 19.8605 7.86058 18.6666 9.33333 18.6666H22.6667C24.1394 18.6666 25.3333 19.8605 25.3333 21.3333V25.3332C25.3333 26.806 24.1394 27.9999 22.6667 27.9999H9.33333C7.86057 27.9999 6.66667 26.806 6.66667 25.3333V21.3333Z", fill: "#1E8C58" }) });
};
export {
  Password,
  Password as default
};

import { K as jsxRuntimeExports, P as joinClass } from "./index-a_Ow1xUN-2024_8_30_15_11.js";
import { ap as css } from "./App-D9NLPZJN-2024_8_30_15_11.js";
const TriangleIcon = ({ className, isSelect = false } = {}) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: joinClass(css.defaultCss, className), width: "24", height: "24", viewBox: "0 0 24 24", fill: "none", xmlns: "http://www.w3.org/2000/svg", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
    "path",
    {
      d: "M12 7L18.0622 14.2692H5.93782L12 7Z",
      fill: "#1F2837"
    }
  ) });
};
export {
  TriangleIcon,
  TriangleIcon as default
};
